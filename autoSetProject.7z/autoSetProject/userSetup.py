import maya.cmds as cmds
import autoSetProject

cmds.evalDeferred(autoSetProject.main)